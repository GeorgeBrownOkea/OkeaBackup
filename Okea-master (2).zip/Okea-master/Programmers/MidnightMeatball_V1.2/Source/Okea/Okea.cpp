// Copyright Epic Games, Inc. All Rights Reserved.

#include "Okea.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Okea, "Okea" );
 